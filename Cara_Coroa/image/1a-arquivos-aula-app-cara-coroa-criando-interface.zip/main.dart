import 'package:cara_ou_coroa/Jogar.dart';
import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(
  home: Jogar(),
  debugShowCheckedModeBanner: false,
));

