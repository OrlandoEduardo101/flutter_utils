import 'package:entrada_dados/CampoTexto.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(
    MaterialApp(
      home: CampoTexto(),
    )
  );
}

